import Card from "react-bootstrap/Card";
import { useContext } from "react";
import { ContextTPComidas } from "../context/context";
import { Button } from "react-native-web";
import { useNavigation } from "@react-navigation/native";
import { StyleSheet } from "react-native";

function CardPlato({ plato, esMenu }) {
    const context = useContext(ContextTPComidas);
    const navigation = useNavigation();

    return (
        <Card style={ styles.card }>
            <Card.Img style={{ width: "100%" }} variant="top" src={plato.image} />
            <Card.Body style={ styles.cardBody }>
                <Card.Title style={{ margin: "0.5rem" }}>{plato.title}</Card.Title>
                <Button title={esMenu ? "Eliminar" : "Ver detalle"} onPress={() => { esMenu ? context.eliminarPlato(plato.id) : navigation.navigate("DetallePlato", { plato }) }}></Button>
            </Card.Body>
        </Card>
    );
}

const styles = StyleSheet.create({
    card: {
        width: "70%",
        border: "1px solid black"
    },
    cardBody: {
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        flexDirection: "column",
        padding: "1%"
    }
});

export default CardPlato;