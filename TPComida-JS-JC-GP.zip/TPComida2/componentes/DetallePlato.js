import { useContext } from "react";
import { ContextTPComidas } from "../context/context";
import { Button, View } from "react-native-web";
import { Image } from "react-bootstrap";
import { StyleSheet } from "react-native";
import { useNavigation } from "@react-navigation/native";

function DetallePlato({ route }) {
    const context = useContext(ContextTPComidas);
    const navigation = useNavigation();

    const plato = route.params.plato;

    const handleClick = () => {
        context.añadirPlato(plato);
        navigation.goBack();
    }

    return (
        <View style={{display: "flex", flexDirection:"row"}}>
            <View style={styles.container}>
                <Image style={{ width: "100%" }} src={plato.image}></Image>
                <Button title="Añadir al menu" onPress={() => handleClick()}></Button>
            </View>
            <h3>{plato.title}</h3>
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        width: "50%",
        height: "50%",
        alignItems: 'center',
        justifyContent: 'center',
        flexDirection: "Column",
        padding: "2%"
    },
});

export default DetallePlato;